setwd("/Users/alokawarnakula/Desktop")

# Question 01
#Import the data set
student_data <- read.csv("Exercise.csv", header=TRUE)


# Question 02
summary(student_data$X1)
hist(student_data$X1, main="Histogram of Age (X1)", 
     xlab="Age", 
     ylab="Frequency", 
     col="lightblue", 
     breaks=seq(17, 27, by=1))

# Question 03
table(student_data$X2)
barplot(table(student_data$X2), main="Bar Chart of Gender (X2)", 
        xlab="Gender", 
        ylab="Frequency", 
        col="lightgreen", 
        names =c("Gender 1", "Gender 2"))

# Question 04
boxplot(X1 ~ X3, data=student_data, main="Age Distribution by Accommodation Type (X3)", 
        xlab="Accommodation Type", 
        ylab="Age (X1)", 
        col=c("lightcoral", "lightblue", "lightgreen"),
        names=c("Type 1", "Type 2", "Type 3"))

