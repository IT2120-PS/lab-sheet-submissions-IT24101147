setwd("C:\\Users\\IT24101147\\Desktop\\Lab08")

data <- read.table("Exercise - LaptopsWeights.txt",header = TRUE)
fix(data)
attach(data)


# Question 1

# Population mean
popmn <- mean(Weight.kg.)

# population standard deviation
popsd <- sd(Weight.kg.)

# Question 2 

sample <- c()
n <- c()

for (i in 1:25){
  s<-sample(Weight.kg.,6,replace = TRUE)
  sample <- cbind(sample,s)
  n<- c(n,paste('S',i))
}

colnames(sample) = n
s.means <- apply(sample,2,mean)
s.vars <- apply(sample,2,var)


# mean and variance of the Sample Means

samplemean <- mean(s.means)
samplevars <- var(s.means)


# Question 3

samplemean
samplevars

s.means
s.vars

