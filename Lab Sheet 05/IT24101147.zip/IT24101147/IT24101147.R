setwd("C:\\Users\\IT24101147\\Desktop\\IT24101147")

#Question 1
Delivery_Times <- read.table("Exercise - Lab 05.txt" , header = TRUE)

fix(Delivery_Times)

colSums(Delivery_Times)

#Question 2
histrogram <-hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = seq(20,70, length = 10),
     right = FALSE,
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     col = "lightblue"
)

#Question 3
#Histogram shows sligh right skewed. Peak around 40 minutes. This means most 
#deliveries complete around 40 minute. Highest frequency around 8-9 in 4th class.


#Question 4
breaks <- round(histrogram$breaks)
freq<- histrogram$counts
mids <-histrogram$mids

classes<- c()

for (i in 1:length(breaks)-1){
  classes[i] <- paste0("[",breaks[i], ",",breaks[i+1],"]")
  
}

cbind(Classes = classes,Frquency = freq)

lines(mids,freq)

cum.freq = cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if (i ==1){
    new[i] = 0
  }else {
    new[i] = cum.freq[i -1]
  }
}

plot(breaks,
     new,
     type = 'l',
     main = 'a cumulative frequency polygon ',
     xlab = 'Minutes',
     ylab = ' cumulative frequency',
     ylim = c(0,max(cum.freq)),
)

cbind(Upper = breaks,CumFreq = new)

     