setwd('/Users/alokawarnakula/Desktop/IT24101147')

#Question 1

#Part i
#Binomial Distribution
#X ~ Binomial(n=50, p=0.85)

#Part ii
#P(X >= 47)
prob_at_least_47 <- pbinom(46, 50, 0.85,lower.tail = FALSE)
prob_at_least_47

#Question ii

#Part i
#X = Number of customer calls received in one hour

#Part ii
#X ~ Poisson(λ=12)

#Part iii
prob_exactly_15 <- dpois(15, 12)
prob_exactly_15
