
setwd("/Users/alokawarnakula/Desktop/Lab09")

# Question Part 1
baking_time <- rnorm(n = 25, mean = 45, sd = 2)
print(baking_time)


# Question Part 2
t_result <- t.test(baking_time, mu = 46, alternative = "less")
print(t_result)

